﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishFunction : MonoBehaviour {
    float time = 0f;
    // Use this for initialization
    void Start () {
	
	}

    // Update is called once per frame
    void Update() {
        /*if (Input.touchCount == 1)
        {
            Vector2 finger = Input.touches[0].position;
            if (gameObject.transform.position.x < finger.x)
                gameObject.transform.position += new Vector3(0.01f, 0, 0);
            if (gameObject.transform.position.x > finger.x)
                gameObject.transform.position -= new Vector3(0.01f, 0, 0);
            if (gameObject.transform.position.y < finger.y)
                gameObject.transform.position += new Vector3(0, 0.01f, 0);
            if (gameObject.transform.position.y > finger.y)
                gameObject.transform.position -= new Vector3(0, 0.01f, 0);
        }*/
        time += Time.deltaTime;
        if (time > 1f)
        {
             int fishmove=0;
            if(time > 1.5f)fishmove = Random.Range(1, 3);

            switch (fishmove)
            {
                case 1:
                        gameObject.transform.position -= new Vector3(0.1f, 0, 0);
                    break;
                case 2:
                    gameObject.transform.position += new Vector3(0.1f, 0, 0);
                    break;
                default:
                    break;
            }
           if (time > 3f) time = 0.5f;
        }

    }
}
